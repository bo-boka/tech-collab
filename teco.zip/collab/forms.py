# from django import forms
# from django.forms import CharField
# from .models import Project
# from .models import Technology
#
#
# class ProjectCreateForm(forms.ModelForm):
#     # technologies = forms.MultiValueField(widget=forms.TextInput())
#
#     # technologies = forms.ModelMultipleChoiceField(queryset=Technology.objects.all(),
#     #                                               widget=forms.CheckboxSelectMultiple())
#
#     # technologies = forms.ModelMultipleChoiceField(queryset=Technology.objects.all(), widget=AreaWidget)
#
#     class Meta:
#         model = Project
#         fields = ['title', 'description', 'technologies']
#
