# tech-collab
Web App that matches techies for projects to collaborate on based on their skills and location. Built using Django, data scraping using BeautifulSoup, Postgres, Apache, and CBVs!
